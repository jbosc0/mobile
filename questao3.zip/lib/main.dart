import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class Item {
  final String title;
  final String imageUrl;
  final String description;

  Item(
      {required this.title, required this.imageUrl, required this.description});
}

class MyApp extends StatelessWidget {
  final List<Item> items = [
    Item(
      title: 'Autismo',
      imageUrl: 'https://images.app.goo.gl/AcAHEP7h58Gpr97X9',
      description:
          'O autismo é um transtorno do neurodesenvolvimento que afeta a comunicação, comportamento e interações sociais.',
    ),
    Item(
      title: 'TDAH',
      imageUrl: 'https://images.app.goo.gl/dSwrPkpFq1HV8QBH9',
      description:
          'O Transtorno de Déficit de Atenção e Hiperatividade (TDAH) é caracterizado por desatenção, hiperatividade e impulsividade.',
    ),
    Item(
      title: 'Dislexia',
      imageUrl: 'https://images.app.goo.gl/PnqzYxX9j6Mw67Nz7',
      description:
          'A dislexia é um distúrbio de aprendizagem que afeta a habilidade de ler, escrever e soletrar, mas não está relacionada à inteligência.',
    ),
    // Adicione mais itens conforme necessário
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neurodiversidade App',
      home: ItemListScreen(items: items),
    );
  }
}

class ItemListScreen extends StatelessWidget {
  final List<Item> items;

  ItemListScreen({required this.items});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Conceitos de Neurodiversidades'),
      ),
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Image.asset(items[index].imageUrl),
            title: Text(items[index].title),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ItemDetailsScreen(item: items[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class ItemDetailsScreen extends StatelessWidget {
  final Item item;

  ItemDetailsScreen({required this.item});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(item.imageUrl),
            SizedBox(height: 20),
            Text(
              item.title,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              item.description,
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
