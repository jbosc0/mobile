package com.example.questao3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
