package com.example.questao2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
